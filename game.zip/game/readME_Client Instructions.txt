Title: Battleship.Jar (for Battleship Game)
Authors: Akshat Sawraj, Altamish Lalani, Andres Tovar
Date: June 11th 2021

Client Instructions

1. After running the server class, run the Battleship.jar Class

2. You'll see a window where you will have to fill in the information it asks for (username, port number, ip).

3. A window will prompt you to place your ships, do so at your leisure. When done click the Start Attacking button.

- Prompts may occur if you do not place your ships properly!!!

4. Send a greeting by placing your cursor on the text field, and clicking the send button once you're done typing.

5. To make a move click on your desired square to attack.

6. Once you've attacked, click the disconnect button, followed by the connect button to hand over control to your opponent.

7. Your opponent will do the same, when it is your turn repeat step 6 until game over.

8. Once game ends click the x on  the top right corner of the window to close the app.
