Title: Server.Jar (for Battleship Game)
Authors: Akshat Sawraj, Altamish Lalani, Andres Tovar
Date: June 11th 2021

Instructions for server

1. Run Server.jar as a Java App.

