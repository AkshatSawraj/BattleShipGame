Title: Battleship Game
Authors: Akshat Sawraj, Altamish Lalani, Andres Tovar
Date: June 11th 2021

List Of deficiencies
Our completeness is 75% Because Server can accept two clients and allow them to play a game of Battleship while logged onto the server.
1. The first tile on both clients always gets hit on start up.
2. We have to manually hand over control to the other person by dissconnecting and reconnecting.
3. The total score reaches 17 and game ends with no possibility to start a new one. Person may optionally re-launch clients.
4. The tiles I hit on my screen dont show up on my client so I dont know what I hit until I look at opponent client. (we coded this in but it is not running the code for it and we are not sure why.)
